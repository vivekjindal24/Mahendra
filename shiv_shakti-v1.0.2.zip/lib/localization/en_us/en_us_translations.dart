final Map<String, String> enUs = {
  // Android Large - One Screen
  "lbl": "आवक", "lbl2": "बकाया एंट्री", "lbl3": "जावक",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
};
