class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Android Large - One images
  static String imgLordShivaWallArt1 =
      '$imagePath/img_lord_shiva_wall_art_1.png';

  static String imgShivShakti1 = '$imagePath/img_shiv_shakti_1.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
